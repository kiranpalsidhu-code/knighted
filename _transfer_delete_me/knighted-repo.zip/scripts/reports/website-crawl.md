# Website Crawl Report

Base URL: https://cfe566cb-76ee-44db-855c-5dbd3492f798-00-e6ansjj4qmyj.riker.replit.dev
Generated: 2026-07-10T03:02:04.571Z

**21 passed, 0 failed** out of 21 routes checked.

> Note: This is an HTTP-level crawl (status codes, response times, payload size). It confirms the server responds correctly for each route but does not execute client-side JavaScript, so it will not catch React runtime errors, broken buttons, or rendering bugs inside the SPA. Pair with the browser-based test suite for full behavioral coverage.

| Route | Description | Status | Result | Time (ms) | Size (bytes) | Note |
|---|---|---|---|---|---|---|
| `/` | Landing page | 200 | ✅ Pass | 147 | 71538 | OK |
| `/pricing` | Pricing tiers | 200 | ✅ Pass | 25 | 71538 | OK |
| `/blog` | Blog index | 200 | ✅ Pass | 24 | 71538 | OK |
| `/privacy` | Privacy policy | 200 | ✅ Pass | 16 | 71538 | OK |
| `/terms` | Terms of service | 200 | ✅ Pass | 13 | 71538 | OK |
| `/contact` | Contact page | 200 | ✅ Pass | 17 | 71538 | OK |
| `/sign-in` | Sign in | 200 | ✅ Pass | 17 | 71538 | OK |
| `/sign-up` | Sign up | 200 | ✅ Pass | 11 | 71538 | OK |
| `/dashboard` | Dashboard | 200 | ✅ Pass | 12 | 71538 | OK |
| `/resumes` | Resumes list | 200 | ✅ Pass | 37 | 71538 | OK |
| `/cover-letters` | Cover letters list | 200 | ✅ Pass | 35 | 71538 | OK |
| `/jobs` | Job search | 200 | ✅ Pass | 15 | 71538 | OK |
| `/pipeline` | Application pipeline | 200 | ✅ Pass | 19 | 71538 | OK |
| `/contacts` | Networking / contacts tracker | 200 | ✅ Pass | 11 | 71538 | OK |
| `/interview` | Interview prep | 200 | ✅ Pass | 13 | 71538 | OK |
| `/feedback` | AI resume feedback | 200 | ✅ Pass | 11 | 71538 | OK |
| `/referrals` | Referral program | 200 | ✅ Pass | 10 | 71538 | OK |
| `/api/resume-ready/dashboard` | Dashboard data (expects 401 unauthenticated) | 401 | ✅ Pass | 11 | 24 | OK |
| `/api/resume-ready/me` | Current user (expects 401 unauthenticated) | 401 | ✅ Pass | 7 | 24 | OK |
| `/api/resume-ready/applications` | Applications list (expects 401 unauthenticated) | 401 | ✅ Pass | 6 | 24 | OK |
| `/api/resume-ready/contacts` | Contacts list (expects 401 unauthenticated) | 401 | ✅ Pass | 7 | 24 | OK |
