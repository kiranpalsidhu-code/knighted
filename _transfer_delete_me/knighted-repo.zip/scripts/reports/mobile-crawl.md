# Mobile App Crawl Report

Base URL: https://cfe566cb-76ee-44db-855c-5dbd3492f798-00-e6ansjj4qmyj.expo.riker.replit.dev
Generated: 2026-07-10T03:02:06.042Z

**4 passed, 0 failed** out of 4 routes checked.

> Note: ResumeReady Mobile is a local-only Expo app (no backend calls, AsyncStorage persistence). This is an HTTP-level crawl of the Expo web preview bundler - it confirms each route's shell loads but does not execute app JS, so it will not catch runtime errors inside screens. Pair with the browser-based test suite for full behavioral coverage.

| Route | Description | Status | Result | Time (ms) | Size (bytes) | Note |
|---|---|---|---|---|---|---|
| `/` | Dashboard tab (pipeline overview) | 200 | ✅ Pass | 158 | 1457 | OK |
| `/jobs` | Applications list tab | 200 | ✅ Pass | 31 | 1457 | OK |
| `/job/new` | Add job application modal | 200 | ✅ Pass | 12 | 1457 | OK |
| `/does-not-exist` | Fallback / not-found screen | 200 | ✅ Pass | 16 | 1457 | OK |
